﻿using System;

namespace ITXCM
{
    public class MathUtil
    {
        public static int RoundToInt(float f) => (int)Math.Round(f);
    }
}