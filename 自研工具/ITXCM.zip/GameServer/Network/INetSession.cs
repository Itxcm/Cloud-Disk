﻿namespace Network
{
    public interface INetSession
    {
        byte[] GetResponse();
    }
}